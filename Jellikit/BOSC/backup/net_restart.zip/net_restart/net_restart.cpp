#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main()
{
	status_t error;
	int trys=0;
	
	//to kill
	BMessenger *usps = new BMessenger("application/x-vnd.Be-NETS",-1,&error);
	if (usps->IsValid())		// test if the net_server is here...
	{
		BMessage *msg = new BMessage(B_QUIT_REQUESTED);
		usps->SendMessage(msg);
		++trys;
		while((error < B_NO_ERROR) || (trys > 4)) //error. retry (upto)5 times
		{
			// cout << "Failure to quit net_server. retrying" << endl;
			sleep(.5); //pause
			usps->SendMessage(msg); //try
			++trys; //increment num of tries
		}
		delete msg;
		delete usps;
	}
	else
		printf ("net_server already dead...\n");
	//end kill

	//to start
	system("/boot/beos/system/boot/Netscript"); //Run Netscript!
	//end start
}